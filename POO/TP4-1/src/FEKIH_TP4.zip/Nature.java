
public enum Nature {
	BARRE , ESPACE
}
