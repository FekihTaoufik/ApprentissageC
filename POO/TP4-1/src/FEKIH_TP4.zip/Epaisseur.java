
public enum Epaisseur {
	LARGE , ETROIT
}
