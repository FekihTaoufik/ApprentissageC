
public class IterateurSymbole {
	boolean terminee() {
		return true;
	}
	void suivant() {
		
	}
}
